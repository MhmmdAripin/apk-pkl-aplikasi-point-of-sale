<?php error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$koneksi = new mysqli("localhost", "root", "", "db_pos");
$content = ' 
<style type="text/css">
    .tabel{border-collapse: collapse;}
    .tabel th{padding: 8px 5px; background-color: #cccccc;}
    .tabel td{padding: 8px 5px;}
</style>
';


    $content .= '

<page>
	<h2>Laporan Data Barang</h2>  

	<table border="1" class="tabel">
		<tr> 
			<th>No</th>
			<th>Kode Barcode</th>
			<th>Nama Barang</th>
			<th>Satuan</th>
			<th>Stok</th>
			<th>Harga Beli</th>
			<th>Harga Jual</th>
			<th>Profit</th>
		</tr>';
      

        $no = 1;

        $sql = $koneksi->query("select * from tb_barang");

        while ($data=$sql->fetch_assoc()) {

        $content .= '

       <tr>
	       
            <td>'.$no++.'</td>
            <td>'.$data['kode_barcode'].'</td>
            <td>'.$data['nama_barang'].'</td>
            <td>'.$data['satuan'].'</td>
            <td>'.$data['stok'].'</td>
            <td>'.$data['harga_beli'].'</td>
            <td>'.$data['harga_jual'].'</td>
            <td>'.$data['profit'].'</td>

	    </tr>

        ';                                
        }                                 
    $content .= '
	</table>

</page>';

require_once('../assets/html2pdf/html2pdf.class.php');
$html2pdf = new HTML2PDF('P','A4','fr');
$html2pdf->WriteHTML($content);
$html2pdf->Output('exemple.pdf');
?>