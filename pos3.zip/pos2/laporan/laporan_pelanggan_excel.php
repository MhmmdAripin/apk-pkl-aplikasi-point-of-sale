<?php error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));

    $koneksi = new mysqli("localhost", "root", "", "db_pos");

    $filename = "pelanggan_exel-(".date('d-m-Y').").xls";

    header("content-disposition: attachment; filename='$filename'");
    header("content-type: application/vdn.ms-exel");

?>

<h2>Laporan Barang</h2>

<table border="1">
	<tr>
	    <th>No</th>
        <th>Nama</th>
        <th>Alamat</th>
        <th>Telpon</th>
        <th>Email</th>   
    </tr>

     <?php

         $no = 1;

         $sql = $koneksi->query("select * from tb_pelanggan");

         while ($data=$sql->fetch_assoc()) {
                                              
     ?>

      <tr>
         
            <td>'.$no++.'</td>
            <td>'.$data['nama'].'</td>
            <td>'.$data['alamat'].'</td>
            <td>'.$data['telpon'].'</td>
            <td>'.$data['email'].'</td>
            
      </tr>



      <?php   } ?>
	
</table>