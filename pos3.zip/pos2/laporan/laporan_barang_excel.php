<?php error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));

    $koneksi = new mysqli("localhost", "root", "", "db_pos");

    $filename = "barang_exel-(".date('d-m-Y').").xls";

    header("content-disposition: attachment; filename='$filename'");
    header("content-type: application/vdn.ms-exel");

?>

<h2>Laporan Barang</h2>

<table border="1">
	<tr>
	    <th>No</th>
	    <th>Kode Barcode</th>
	    <th>Nama Barang</th>
      <th>Satuan</th>
	    <th>Stok</th>
	    <th>Harga Beli</th>
      <th>Harga Jual</th>
      <th>Profit</th>
	   
    </tr>

     <?php

         $no = 1;

         $sql = $koneksi->query("select * from tb_barang");

         while ($data=$sql->fetch_assoc()) {
                                              
     ?>

      <tr>
         
            <td>'.$no++.'</td>
            <td>'.$data['kode_barcode'].'</td>
            <td>'.$data['nama_barang'].'</td>
            <td>'.$data['satuan'].'</td>
            <td>'.$data['stok'].'</td>
            <td>'.$data['harga_beli'].'</td>
            <td>'.$data['harga_jual'].'</td>
            <td>'.$data['profit'].'</td>

      </tr>



      <?php   } ?>
	
</table>