<?php error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));

    $koneksi = new mysqli("localhost", "root", "", "db_pos");

    $filename = "pengguna_exel-(".date('d-m-Y').").xls";

    header("content-disposition: attachment; filename='$filename'");
    header("content-type: application/vdn.ms-exel");

?>

<h2>Laporan Barang</h2>

<table border="1">
	<tr>
	    <th>No</th>
        <th>Username</th>
        <th>Nama</th>
        <th>Password</th>
        <th>Level</th> 
    </tr>

     <?php

         $no = 1;

         $sql = $koneksi->query("select * from tb_pengguna");

         while ($data=$sql->fetch_assoc()) {
                                              
     ?>

      <tr>
         
            <td>'.$no++.'</td>
            <td>'.$data['username'].'</td>
            <td>'.$data['nama'].'</td>
            <td>'.$data['password'].'</td>
            <td>'.$data['level'].'</td>
            
      </tr>



      <?php   } ?>
	
</table>