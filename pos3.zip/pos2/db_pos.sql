-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Sep 2021 pada 17.32
-- Versi server: 10.1.37-MariaDB
-- Versi PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_pos`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_barang`
--

CREATE TABLE `tb_barang` (
  `kode_barcode` varchar(50) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `satuan` varchar(50) NOT NULL,
  `harga_beli` int(11) NOT NULL,
  `stok` int(11) NOT NULL,
  `harga_jual` int(11) NOT NULL,
  `profit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_barang`
--

INSERT INTO `tb_barang` (`kode_barcode`, `nama_barang`, `satuan`, `harga_beli`, `stok`, `harga_jual`, `profit`) VALUES
('453345678970', 'Redmi Note 7', 'PCS', 3700000, 3, 3900000, 200000),
('6799564237178', 'Xiaomi Black Shark', 'PCS', 15699999, 5, 16400000, 700001),
('7789561421777', 'Xiaomi Black Shark 2', 'PCS', 17600000, 7, 18699998, 1100000),
('7895565499076', 'Rog Phone', 'PCS', 1700000, 6, 1800000, 100000),
('879366789990', 'Rog Phone 2', 'PCS', 19500000, 7, 20600000, 1100000),
('9982678024556', 'Redmi Note 5', 'PCS', 3300000, 7, 3400000, 100000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pelanggan`
--

CREATE TABLE `tb_pelanggan` (
  `kode_pelanggan` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `telpon` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pelanggan`
--

INSERT INTO `tb_pelanggan` (`kode_pelanggan`, `nama`, `alamat`, `telpon`, `email`) VALUES
(4, 'Fahrurozi ', 'Bandung', '085733421322', 'fahrurozi123@gmail.com'),
(5, 'parman blora', 'Bogor Selatan', '089677843212', 'blora@gmail.com'),
(6, 'Dimas Sumantri', 'Jakarta Selatan', '089566007562', 'dimasmantri123@gmail.com'),
(7, 'Herlansyah ', 'Jakarta Utara', '089677863214', 'herlan123@gmail.com'),
(8, 'Asep', ' Kab.Bogor   ', '083875643214', 'asep123@gmail.com'),
(9, 'teh gelas', 'Bandung', '834734756475', 'admin@gmail.com'),
(10, 'Rizal', 'Garut', '081992267600', 'rizalrc09@gmail.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pengguna`
--

CREATE TABLE `tb_pengguna` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `level` varchar(20) NOT NULL,
  `foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pengguna`
--

INSERT INTO `tb_pengguna` (`id`, `username`, `nama`, `password`, `level`, `foto`) VALUES
(1, 'admin', 'Yuanthio', 'admin', 'admin', 'thio1.jpg'),
(15, 'fuziq', 'Anggara', '12345', 'kasir', 'IMG_20190829_223127.jpg'),
(16, 'diva', 'Aulia', '54321', 'kasir', 'IMG_20190902_160717.jpg'),
(17, 'erlin', 'Juliani', '11223', 'kasir', 'poster-mockup-2853842__480-picsay.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_penjualan`
--

CREATE TABLE `tb_penjualan` (
  `id` int(11) NOT NULL,
  `kode_penjualan` varchar(20) NOT NULL,
  `kode_barcode` varchar(50) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `tgl_penjualan` date NOT NULL,
  `id_pelanggan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_penjualan`
--

INSERT INTO `tb_penjualan` (`id`, `kode_penjualan`, `kode_barcode`, `jumlah`, `total`, `tgl_penjualan`, `id_pelanggan`) VALUES
(54, 'PJ-0148516309', '5677111145672', 1, 7000, '2019-05-11', 0),
(55, 'PJ-0148516309', '3378904532569', 1, 10000, '2019-05-11', 0),
(56, 'PJ-3234057006', '4562334455436', 1, 8000, '2019-05-11', 4),
(57, 'PJ-4911275289', '4562334455436', 1, 8000, '2019-05-11', 3),
(58, 'PJ-0950959621', '5677111145672', 1, 7000, '2019-05-11', 3),
(59, 'PJ-1633873432', '5677111145672', 1, 7000, '2019-05-11', 3),
(60, 'PJ-7892177505', '3378904532569', 1, 10000, '2019-05-11', 3),
(61, 'PJ-3900984169', '3455778123213', 1, 8000, '2019-05-12', 0),
(62, 'PJ-5161082169', '5677111145672', 1, 7000, '2019-05-12', 3),
(63, 'PJ-3317733619', '3378904532569', 1, 10000, '2019-05-12', 4),
(64, 'PJ-2736872216', '3455778123213', 1, 8000, '2019-05-12', 4),
(65, 'PJ-2736872216', '3378904532569', 1, 10000, '2019-05-12', 4),
(66, 'PJ-5611231205', '5677111145672', 1, 7000, '2019-05-12', 3),
(67, 'PJ-5611231205', '3455778123213', 1, 8000, '2019-05-12', 3),
(68, 'PJ-5611231205', '3378904532569', 1, 10000, '2019-05-12', 3),
(69, 'PJ-2999710979', '5677111145672', 1, 7000, '2019-05-12', 4),
(70, 'PJ-9467185024', '3455778123213', 1, 8000, '2019-05-12', 3),
(71, 'PJ-0447714179', '4562334455436', 1, 8000, '2019-05-12', 3),
(72, 'PJ-3064136774', '5677111145672', 1, 7000, '2019-05-12', 3),
(73, 'PJ-1644650445', '3455778123213', 1, 8000, '2019-05-12', 3),
(74, 'PJ-1258629003', '5677111145672', 1, 7000, '2019-05-12', 3),
(75, 'PJ-4548167454', '4562334455436', 1, 8000, '2019-05-12', 3),
(76, 'PJ-0884970702', '3378904532569', 1, 10000, '2019-05-12', 3),
(77, 'PJ-9276260116', '3378904532569', 1, 10000, '2019-05-14', 3),
(78, 'PJ-4171864831', '4562334455436', 1, 8000, '2019-05-14', 3),
(79, 'PJ-0368454195', '3455778123213', 1, 8000, '2019-05-14', 3),
(80, 'PJ-4422538005', '5677111145672', 1, 7000, '2019-05-14', 3),
(81, 'PJ-6810039462', '3455778123213', 1, 8000, '2019-05-14', 0),
(82, 'PJ-0865550633', '4562334455436', 1, 8000, '2019-05-14', 0),
(83, 'PJ-5871524380', '5677111145672', 1, 7000, '2019-05-14', 0),
(84, 'PJ-5556121121', '4562334455436', 1, 8000, '2019-05-14', 0),
(85, 'PJ-1470906999', '4562334455436', 1, 8000, '2019-05-14', 0),
(86, 'PJ-3562961710', '5677111145672', 1, 7000, '2019-05-14', 0),
(87, 'PJ-8552581729', '5677111145672', 1, 7000, '2019-05-14', 0),
(88, 'PJ-3658203296', '3455778123213', 1, 8000, '2019-05-14', 0),
(89, 'PJ-2753876121', '3378904532569', 1, 10000, '2019-05-14', 0),
(90, 'PJ-5698759009', '5677111145672', 2, 7000, '2019-05-14', 0),
(91, 'PJ-2099594284', '3378904532569', 2, 10000, '2019-05-14', 0),
(92, 'PJ-1424717469', '3455778123213', 2, 16000, '2019-05-14', 0),
(93, 'PJ-5012025050', '4562334455436', 2, 16000, '2019-05-14', 3),
(94, 'PJ-2193857302', '3378904532569', 2, 20000, '2019-05-14', 0),
(95, 'PJ-9315093502', '3378904532569', 1, 10000, '2019-05-14', 0),
(96, 'PJ-0559002278', '5797643326543', 1, 6500, '2019-05-15', 5),
(97, 'PJ-6378705756', '5677111145672', 1, 7000, '2019-05-15', 3),
(98, 'PJ-3869153694', '3378904532569', 1, 10000, '2019-05-15', 3),
(99, 'PJ-3458474712', '3455778123213', 1, 8000, '2019-05-15', 3),
(100, 'PJ-2965732599', '345223467821', 2, 46000, '2019-05-16', 3),
(101, 'PJ-7857708929', '4352667532156', 3, 48000, '2019-05-16', 3),
(102, 'PJ-8013753059', '3452234678216', 2, 46000, '2019-05-17', 4),
(103, 'PJ-6580797618', '5463728991792', 2, 35998, '2019-05-17', 0),
(104, 'PJ-8159554707', '5463728991792', 2, 34000, '2019-05-17', 5),
(105, 'PJ-6396428485', '4562334455436', 3, 52500, '2019-05-19', 3),
(106, 'PJ-6396428485', '4562334455436', 2, 35000, '2019-05-19', 3),
(107, 'PJ-6396428485', '3378904532569', 4, 60000, '2019-05-19', 3),
(109, 'PJ-2809664128', '7890354672131', 3, 27000, '2019-05-19', 4),
(110, 'PJ-9072189650', '5797643326543', 2, 13000, '2019-05-19', 6),
(111, 'PJ-4044237025', '5463728991792', 3, 51000, '2019-05-19', 5),
(112, 'PB-3711635739', '5677111145672', 1, 7000, '2019-05-20', 0),
(113, 'PJ-0534993884', '3378904532569', 1, 15000, '2019-05-20', 3),
(114, 'PJ-4434596391', '3378904532569', 1, 15000, '2019-05-21', 3),
(115, 'PB-4623578802', '3378904532569', 1, 15000, '2019-05-22', 0),
(116, 'PB-4623578802', '3378904532569', 1, 15000, '2019-05-22', 0),
(117, 'PB-8930166092', '5677111145672', 1, 7000, '2019-05-22', 0),
(118, 'PB-8930166092', '5677111145672', 1, 7000, '2019-05-22', 0),
(121, 'PJ-8920298653', '3378904532569', 1, 15000, '2019-05-22', 0),
(122, 'PJ-8920298653', '3378904532569', 1, 15000, '2019-05-22', 0),
(123, 'PJ-8920298653', '3378904532569', 1, 15000, '2019-05-22', 0),
(124, 'PJ-7522317368', '3378904532569', 1, 15000, '2019-05-22', 0),
(125, 'PJ-8451118492', '3378904532569', 1, 15000, '2019-05-22', 0),
(126, 'PJ-8451118492', '3378904532569', 1, 15000, '2019-05-22', 0),
(140, 'PJ-1724230990', '3378904532569', 1, 15000, '2019-05-22', 0),
(142, 'PJ-7388881145', '7890354672131', 1, 9000, '2019-08-21', 4),
(143, 'PJ-8599111861', '1236345289765', 1, 1200000, '2019-08-30', 4),
(144, 'PJ-4894159098', '6787776512345', 1, 10000, '2019-08-30', 0),
(145, 'PJ-9153472447', '5797643326543', 1, 6500, '2019-08-31', 0),
(146, 'PJ-9024996170', '1236345289765', 1, 1200000, '2019-09-04', 4),
(147, 'PJ-8234928098', '5463728991792', 1, 17000, '2019-09-05', 0),
(148, 'PJ-1416027045', '6787776512345', 1, 10000, '2019-09-05', 4),
(149, 'PJ-3903450449', '4562334455436', 4, 70000, '2019-09-05', 4),
(150, 'PJ-1677950469', '5671235689012', 2, 770000, '2019-09-05', 4),
(151, 'PJ-9292737413', '4352667532156', 1, 16000, '2019-09-09', 4),
(152, 'PJ-2231300946', '4352667532156', 1, 16000, '2019-09-09', 0),
(153, 'PJ-9667981520', '4562334455436', 1, 17500, '2019-09-09', 0),
(154, 'PJ-9667981520', '1236345289765', 1, 1200000, '2019-09-09', 0),
(155, 'PJ-0968657386', '453345678970', 2, 7800000, '2019-09-20', 4),
(156, 'PJ-4546836729', '879366789990', 1, 20600000, '2019-09-20', 4),
(157, 'PJ-2951016185', '9982678024556', 3, 10200000, '2020-10-14', 4),
(158, 'PJ-6069487700', '453345678970', 1, 3900000, '2021-09-02', 4);

--
-- Trigger `tb_penjualan`
--
DELIMITER $$
CREATE TRIGGER `jual` AFTER INSERT ON `tb_penjualan` FOR EACH ROW BEGIN
UPDATE  tb_barang
SET stok = stok - NEW.jumlah
WHERE
kode_barcode = NEW.kode_barcode;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_penjualan_detail`
--

CREATE TABLE `tb_penjualan_detail` (
  `kode_penjualan` varchar(50) NOT NULL,
  `bayar` int(11) NOT NULL,
  `kembali` int(11) NOT NULL,
  `diskon` int(11) NOT NULL,
  `potongan` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_penjualan_detail`
--

INSERT INTO `tb_penjualan_detail` (`kode_penjualan`, `bayar`, `kembali`, `diskon`, `potongan`, `total`) VALUES
('PJ-4434596391', 16000, 2500, 10, 1500, 13500),
('', 0, 0, 0, 0, 0),
('PJ-7388881145', 10000, 1900, 10, 900, 8100),
('PJ-8599111861', 2000000, 920000, 10, 120000, 1080000),
('PJ-9024996170', 1200000, 120000, 10, 120000, 1080000),
('PJ-1416027045', 10000, 1000, 10, 1000, 9000),
('PJ-3903450449', 90000, 23500, 5, 3500, 66500),
('PJ-1677950469', 799999, 107000, 10, 77000, 693000),
('PJ-9292737413', 15000, 600, 10, 1600, 14400),
('PJ-0968657386', 8000000, 590000, 5, 390000, 7410000),
('PJ-4546836729', 20999997, 1224000, 4, 824000, 19776000),
('PJ-2951016185', 200000000, 190820000, 10, 1020000, 9180000),
('PJ-6069487700', 5000000, 1490000, 10, 390000, 3510000);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_barang`
--
ALTER TABLE `tb_barang`
  ADD PRIMARY KEY (`kode_barcode`);

--
-- Indeks untuk tabel `tb_pelanggan`
--
ALTER TABLE `tb_pelanggan`
  ADD PRIMARY KEY (`kode_pelanggan`);

--
-- Indeks untuk tabel `tb_pengguna`
--
ALTER TABLE `tb_pengguna`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_penjualan`
--
ALTER TABLE `tb_penjualan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_pelanggan`
--
ALTER TABLE `tb_pelanggan`
  MODIFY `kode_pelanggan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `tb_pengguna`
--
ALTER TABLE `tb_pengguna`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `tb_penjualan`
--
ALTER TABLE `tb_penjualan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
