<?php

$tgl = date("Y-m-d");

$sql = $koneksi->query("select * from tb_penjualan, tb_barang where tb_penjualan.kode_barcode=tb_barang.kode_barcode and tgl_penjualan='$tgl'");

while ($tampil = $sql->fetch_assoc()) {
    $profit = $tampil['profit'] * $tampil['jumlah'];
    $total_pj = $total_pj + $tampil['total'];
    $total_profit = $total_profit + $profit;
}

$sql2 = $koneksi->query("select * from tb_barang");

while ($tampil2 = $sql2->fetch_assoc()) {
    $jumlah_brg = $sql2->num_rows;
}

?>

<marquee>Selamat Datang di Sistem informasi Penjualan </marquee>
<div class="container-fluid">
    <div class="block-header">
        <h2>DASHBOARD</h2>
    </div>

    <!-- Widgets -->
    <div class="row clearfix">
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="info-box bg-pink hover-expand-effect">
                <div class="icon">
                    <i class="material-icons">playlist_add_check</i>
                </div>
                <div class="content">
                    <div class="text">Data Barang</div>
                    <div class="number count-to" data-from="0" data-to="125" data-speed="15" data-fresh-interval="20"><?php echo $jumlah_brg; ?></div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="info-box bg-cyan hover-expand-effect">
                <div class="icon">
                    <i class="material-icons">add_shopping_cart</i>
                </div>
                <div class="content">
                    <div class="text">Penjualan Hari Ini</div>
                    <div class="number count-to" data-from="0" data-to="257" data-speed="1000" data-fresh-interval="20"><?php echo "Rp" . "&nbsp" . number_format($total_pj); ?></div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="info-box bg-light-green hover-expand-effect">
                <div class="icon">
                    <i class="material-icons">attach_money</i>
                </div>
                <div class="content">
                    <div class="text">Profit Hari Ini</div>
                    <div class="number count-to" data-from="0" data-to="243" data-speed="1000" data-fresh-interval="20"><?php echo "Rp" . "&nbsp" . number_format($total_profit); ?></div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="info-box bg-cyan hover-zoom-effect">
                <div class="icon">
                    <i class="material-icons">gps_fixed</i>
                </div>
                <div class="content">
                    <div class="text">Lokasi</div>
                    <div class="number">Bogor</div>
                </div>
            </div>
        </div>
    </div>

    <hr>

    <br>

    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                <div class="header">
                    <h2>
                        GALLERY POINT OF SALE
                    </h2>

                </div>
                <div class="body">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" role="tablist">

                        <li role="presentation">
                            <a href="#profile_with_icon_title" data-toggle="tab">
                                <i class="material-icons">face</i> ABOUT
                            </a>
                        </li>
                        <li role="presentation">
                            <a href="#messages_with_icon_title" data-toggle="tab">
                                <i class="material-icons">photo_library</i> GALLERY
                            </a>
                        </li>

                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content">

                        <div role="tabpanel" class="tab-pane fade" id="profile_with_icon_title">
                            <h3>Pengertian Point of Sale</h3>
                            <P> POS atau Point of Sale adalah sebuah sistem yang digunakan untu melakukan transaksi penjualan retail, seperti di restoran atau cafe misalnya. Umumnya sebuah sistem POS merupakan seperangkat komputer dan mesin kasir(cash register).</p>

                            <h3>Point of Sale Software seperti apa yang paling baik untuk digunakan?</h3>
                            <p>Ada banyak sistem software POS populer yang memungkinkan Anda untuk menggunakan perangkat tambahan di stasiun checkout Anda, termasuk kasir elektronik, scanner barcode, pembaca kartu kredit, dan printer struk billing atau faktur.Sistem POS pada umumnya dilengkapi dengan modul akuntansi terintegrasi, termasuk buku besar, piutang, sistem hutang, pembelian, dan perpajakan, serta pengendalian persediaan.Pada dasarnya, Point of Sale adalah cara praktis untuk melacak arus kas bisnis Anda. Seperti sistem POS dari NADIPOS, yang dapat memberikan manfaat nyata dalam hal penghematan biaya dibanding sistem kasir tradisional.Sistem POS digital juga mungkin meningkatkan penjualan melalui peningkatan kepuasan pelanggan dalam hal customer service yang ringkas dan cepat tanggap. Fitur selengkapnya Anda bisa dibaca di sini.</p>
                            <h3>Keuntungan Sistem Point of Sale (POS) Berbasis Web</h3>
                            <ul>
                                <li>Solusi POS real-time</li>
                                <li>Kompatibel dengan sebagian besar komputer selama mereka terhubung ke Internet (sempurna untuk bisnis yang sudah memiliki perangkat keras POS)</li>
                                <li>Solusi POS sering dapat disesuaikan dengan kebutuhan bisnis Anda</li>
                                <li>Menghabiskan sebagian kecil dari Sistem POS tradisional (ideal untuk pengecer independen)</li>
                                <li>Perangkat lunak yang dihosting di server aman dan di beberapa pusat data, sehingga informasi Anda akan selalu dicadangkan</li>
                            </ul>
                        </div>

                        <div role="tabpanel" class="tab-pane fade" id="messages_with_icon_title">
                            <b>Gallery</b>
                            <div class="body">
                                <div id="aniimated-thumbnials" class="list-unstyled row clearfix">
                                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                                        <a href="images/image-gallery/images 1.jpg" data-sub-html="Demo Description">
                                            <img class="img-responsive thumbnail" src="images/image-gallery/images 1.jpg">
                                        </a>
                                    </div>
                                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                                        <a href="images/image-gallery/images 2.jpg" data-sub-html="Demo Description">
                                            <img class="img-responsive thumbnail" src="images/image-gallery/thumb/images 2.jpg">
                                        </a>
                                    </div>
                                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                                        <a href="images/image-gallery/images 3.jpg" data-sub-html="Demo Description">
                                            <img class="img-responsive thumbnail" src="images/image-gallery/thumb/images 3.jpg">
                                        </a>
                                    </div>
                                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                                        <a href="images/image-gallery/images 4.jpg" data-sub-html="Demo Description">
                                            <img class="img-responsive thumbnail" src="images/image-gallery/thumb/images 4.jpg">
                                        </a>
                                    </div>
                                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                                        <a href="images/image-gallery/images 5.jpg" data-sub-html="Demo Description">
                                            <img class="img-responsive thumbnail" src="images/image-gallery/thumb/images 5.jpg">
                                        </a>
                                    </div>
                                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                                        <a href="images/image-gallery/images 6.jpg" data-sub-html="Demo Description">
                                            <img class="img-responsive thumbnail" src="images/image-gallery/thumb/images 6.jpg">
                                        </a>
                                    </div>
                                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                                        <a href="images/image-gallery/images 7.jpg" data-sub-html="Demo Description">
                                            <img class="img-responsive thumbnail" src="images/image-gallery/thumb/images 7.jpg">
                                        </a>
                                    </div>
                                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                                        <a href="images/image-gallery/images 8.jpg" data-sub-html="Demo Description">
                                            <img class="img-responsive thumbnail" src="images/image-gallery/thumb/images 8.jpg">
                                        </a>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>