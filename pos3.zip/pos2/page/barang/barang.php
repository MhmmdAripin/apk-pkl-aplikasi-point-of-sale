<div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Data Barang
                            </h2>
                            
                        </div>
                        <div class="body">

                                <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Kode Barcode</th>
                                            <th>Nama Barang</th>
                                            <th>Satuan</th>
                                            <th>Stok</th>
                                            <th>Harga Beli</th>
                                            <th>Harga Jual</th>
                                            <th>Profit</th>
                                            <?php if ($_SESSION['admin'] ) { ?>
                                            <th>Aksi</th>
                                            <?php } ?>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>

                                            <?php 

                                                $no= 1;
                                            
                                                $sql = $koneksi->query("select * from tb_barang");

                                                while ($data = $sql->fetch_assoc()) {

                                                
                                            ?>

                                        <tr>
                                            <td><?php echo $no++; ?></td>
                                            <td><?php echo $data['kode_barcode'] ?></td>
                                            <td><?php echo $data['nama_barang'] ?></td>
                                            <td><?php echo $data['satuan'] ?></td>

                                            <td><?php echo $data['stok'] ?></td>
                                            <td><?php echo $data['harga_beli'] ?></td>
                                            <td><?php echo $data['harga_jual'] ?></td>
                                            <td><?php echo $data['profit'] ?></td>
                                            <td>

                                                <?php if ($_SESSION['admin'] ) { ?>
                                                <a href="?page=barang&aksi=ubah&id=<?php echo $data['kode_barcode'] ?>" class="btn btn-success"><i class="material-icons">edit</i>Ubah</a>
                                                <a onclick="return confirm('Apakah Anda Yakin Ingin Menghapus Data Ini...???')" href="?page=barang&aksi=hapus&id=<?php echo $data['kode_barcode'] ?>" class="btn btn-danger" ><i class="material-icons">delete</i>Hapus</a>
                                                <?php } ?>

                                            </td>
                                        </tr>
                                        
                                        <?php } ?>

                                     </tbody>
                                </table>
                                <?php if ($_SESSION['admin'] ) { ?>
                                <a href="?page=barang&aksi=tambah" class="btn btn-primary"><i class="material-icons">add</i>Tambah</a>
                                <a href="page/barang/cetak.php" target="blank" class="btn btn-success"><i class="material-icons">print</i>Cetak</a>
                                <?php } ?>
                                <a href="laporan/laporan_barang_pdf.php" target="blank" class="btn btn-success"><i class="material-icons">print</i>ExportToPdf</a>
                                <a href="laporan/laporan_barang_excel.php" target="blank" class="btn btn-success"><i class="material-icons">print</i>ExportToExcel</a>
                                